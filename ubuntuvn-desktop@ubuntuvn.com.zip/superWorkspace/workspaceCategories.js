const {Gio} = imports.gi;
const Me = imports.misc.extensionUtils.getCurrentExtension();

/* exported WorkspaceCategories */


